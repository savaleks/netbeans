package lt.baltictalents.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Aleksandras Novikovas <Aleksandras.Novikovas@gmail.com>
 */
@Entity
@Table(name = "people")
public class People implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer id;
    private String firstName;
    private String lastName;
    private Date birthDate;
    private BigDecimal salary;
    private List<Addresses> addressesList;
    private List<Phones> phonesList;

    public People() {
    }

    public People(Integer id) {
        this.id = id;
    }

    public People(Integer id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "first_name", nullable = false)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name = "last_name", nullable = false)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column(name = "birth_date")
    @Temporal(TemporalType.DATE)
    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    @Column(name = "salary")
    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "people", fetch = FetchType.EAGER)
    public List<Addresses> getAddressesList() {
        return addressesList;
    }

    public void setAddressesList(List<Addresses> addressesList) {
        this.addressesList = addressesList;
    }

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "people", fetch = FetchType.EAGER)
    public List<Phones> getPhonesList() {
        return phonesList;
    }

    public void setPhonesList(List<Phones> phonesList) {
        this.phonesList = phonesList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof People)) {
            return false;
        }
        People other = (People) object;
        return !((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)));
    }

    @Override
    public String toString() {
        return "lt.baltictalents.bean.People[ "
                + "id=" + id + ", "
                + "firstName=" + firstName + ", "
                + "lastName=" + lastName + ", "
                + "birthDate=" + birthDate + ", "
                + "salary=" + salary
                + " ]";
    }

    public void update(People p) {
        if (p == null) {
            return;
        }
        this.setFirstName(p.getFirstName());
        this.setLastName(p.getLastName());
        this.setBirthDate(p.getBirthDate());
        this.setSalary(p.getSalary());
    }
}
