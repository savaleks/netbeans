package lt.baltictalents.bean;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author Aleksandras Novikovas <Aleksandras.Novikovas@gmail.com>
 */
@Entity
@Table(name = "phones")
@NamedQueries({
    @NamedQuery(name = "Phones.findAll", query = "SELECT p FROM Phones p")})
public class Phones implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer id;
    private String type;
    private String phone;
    private People people;

    public Phones() {
    }

    public Phones(Integer id) {
        this.id = id;
    }

    public Phones(Integer id, String phone) {
        this.id = id;
        this.phone = phone;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Column(name = "phone", nullable = false)
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JoinColumn(name = "people_id", referencedColumnName = "id")
    @ManyToOne(optional = false)
    public People getPeople() {
        return people;
    }

    public void setPeople(People people) {
        this.people = people;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Phones)) {
            return false;
        }
        Phones other = (Phones) object;
        return !((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id)));
    }

    @Override
    public String toString() {
        return "lt.baltictalents.bean.Phones[ "
                + "id=" + id + ", "
                + "type=" + type + ", "
                + "phone=" + phone
                + " ]";
    }

    public void update(Phones p) {
        if (p == null) {
            return;
        }
        this.setType(p.getType());
        this.setPhone(p.getPhone());
    }
}
