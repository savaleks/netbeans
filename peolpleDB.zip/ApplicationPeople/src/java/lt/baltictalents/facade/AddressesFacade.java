package lt.baltictalents.facade;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import lt.baltictalents.bean.Addresses;
import lt.baltictalents.bean.People;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AddressesFacade {

    private static final Log log = LogFactory.getLog(AddressesFacade.class);

    public static Addresses get(Integer id) {
        if (id == null) {
            log.warn("id=null was passed to find address entity. Returning null.");
            return null;
        }
        EntityManager em = null;
        try {
            em = EMF.getEntityManager();
            Addresses a = em.find(Addresses.class, id);
            return a;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static List<Addresses> getForPeople(Integer id) {
        EntityManager em = null;
        try {
            em = EMF.getEntityManager();
            People p = em.find(People.class, id);
            if (p != null) {
                return p.getAddressesList();
            }
            log.warn("People entity with id=" + id + " not found. Returning null.");
            return null;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static Addresses add(Addresses a, Integer peopleId) throws Exception {
        // Make sure that id is not specified - it will be set by database
        a.setId(null);
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            People p = em.find(People.class, peopleId);
            a.setPeople(p);
            em.persist(a);
            EMF.commitTransaction(tx);
            return a;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            throw ex;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static Addresses update(Addresses a) throws Exception {
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            Addresses aDB = em.find(Addresses.class, a.getId());
            if (aDB != null) {
                aDB.update(a);
            }
            EMF.commitTransaction(tx);
            return aDB;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            throw ex;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static Addresses remove(Integer id) {
        if (id == null) {
            log.warn("id=null was passed to remove address entity. Skipping.");
            return null;
        }
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            Addresses a = em.find(Addresses.class, id);
            if (a != null) {
                a.getPeople().getAddressesList().remove(a);
                em.remove(a);
                EMF.commitTransaction(tx);
                return a;
            } else {
                log.warn("Address entity with id=" + id + " not found.");
                return null;
            }
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            log.error("Failed to remove address entity with id=" + id, ex);
            return null;
        } finally {
            EMF.returnEntityManager(em);
        }
    }


}
