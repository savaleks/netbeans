package lt.baltictalents.facade;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import lt.baltictalents.bean.People;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PeopleFacade {

    private static final Log log = LogFactory.getLog(People.class);

    public static People get(Integer id) {
        if (id == null) {
            log.warn("id=null was passed to find people entity. Returning null.");
            return null;
        }
        EntityManager em = null;
        try {
            em = EMF.getEntityManager();
            People p = em.find(People.class, id);
            return p;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static List<People> get() {
        EntityManager em = null;
        try {
            em = EMF.getEntityManager();
            Query q = em.createQuery("select p from People p");
            List<People> list = q.getResultList();
            return list;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static People add(People p) throws Exception {
        // Make sure that id is not specified - it will be set by database
        p.setId(null);
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            em.persist(p);
            EMF.commitTransaction(tx);
            return p;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            throw ex;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static People update(People p) throws Exception {
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            People pDB = em.find(People.class, p.getId());
            if (pDB != null) {
                pDB.update(p);
            }
            EMF.commitTransaction(tx);
            return pDB;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            throw ex;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static People remove(Integer id) {
        if (id == null) {
            log.warn("id=null was passed to remove people entity. Skipping.");
            return null;
        }
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            People p = em.find(People.class, id);
            if (p != null) {
                em.remove(p);
            } else {
                log.warn("People entity with id=" + id + " not found.");
            }
            EMF.commitTransaction(tx);
            return p;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            log.error("Failed to remove people entity with id=" + id, ex);
            return null;
        } finally {
            EMF.returnEntityManager(em);
        }
    }
}
