/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lt.baltictalents.facade;

import java.util.List;
import javax.persistence.EntityManager;
import lt.baltictalents.bean.People;
import lt.baltictalents.bean.Phones;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 * @author PC
 */
public class PhoneFacade {
    private static final Log log = LogFactory.getLog(PhoneFacade.class);

    public static Phones get(Integer id) {
        if (id == null) {
            log.warn("id=null was passed to find address entity. Returning null.");
            return null;
        }
        EntityManager em = null;
        try {
            em = EMF.getEntityManager();
            Phones b = em.find(Phones.class, id);
            return b;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static List<Phones> getForPeople(Integer id) {
        EntityManager em = null;
        try {
            em = EMF.getEntityManager();
            People p = em.find(People.class, id);
            if (p != null) {
                return p.getPhonesList();
            }
            log.warn("People entity with id=" + id + " not found. Returning null.");
            return null;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static Phones add(Phones b, Integer peopleId) throws Exception {
        // Make sure that id is not specified - it will be set by database
        b.setId(null);
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            People p = em.find(People.class, peopleId);
            b.setPeople(p);
            em.persist(b);
            EMF.commitTransaction(tx);
            return b;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            throw ex;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static Phones update(Phones a) throws Exception {
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            Phones aDB = em.find(Phones.class, a.getId());
            if (aDB != null) {
                aDB.update(a);
            }
            EMF.commitTransaction(tx);
            return aDB;
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            throw ex;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

    public static Phones remove(Integer id) {
        if (id == null) {
            log.warn("id=null was passed to remove address entity. Skipping.");
            return null;
        }
        EntityManager em = null;
        Object tx = null;
        try {
            em = EMF.getEntityManager();
            tx = EMF.getTransaction(em);
            Phones b = em.find(Phones.class, id);
            if (b != null) {
                b.getPeople().getPhonesList().remove(b);
                em.remove(b);
                EMF.commitTransaction(tx);
                return b;
            } else {
                log.warn("Address entity with id=" + id + " not found.");
                return null;
            }
        } catch (Exception ex) {
            if (tx != null) {
                EMF.rollbackTransaction(tx);
            }
            log.error("Failed to remove address entity with id=" + id, ex);
            return null;
        } finally {
            EMF.returnEntityManager(em);
        }
    }

}
