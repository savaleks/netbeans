package lt.baltictalents.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lt.baltictalents.bean.Addresses;
import lt.baltictalents.facade.AddressesFacade;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@WebServlet(name = "EditAddresses", urlPatterns = {"/editAddresses"})
public class EditAddresses extends HttpServlet {

    private static final Log log = LogFactory.getLog(EditAddresses.class);

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request  servlet request
     * @param response servlet response
     *
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String idParam = request.getParameter("id");
        Addresses a = new Addresses();
        Integer id = null;
        try {
            id = new Integer(idParam);
            a.setId(id);
        } catch (Exception ex) {
            // Ignored
        }
        String peopleIdParam = request.getParameter("peopleId");
        Integer peopleId = null;
        try {
            peopleId = new Integer(peopleIdParam);
        } catch (Exception ex) {
            if (id == null) {
                log.warn("Invalid peopleId parameter value (" + peopleIdParam + ").");
                response.sendRedirect("index.jsp");
            }
        }
        a.setAddress(request.getParameter("address"));
        a.setCity(request.getParameter("city"));
        a.setPostalCode(request.getParameter("postalCode"));
        try {
            if (id == null) {
                a = AddressesFacade.add(a, peopleId);
            } else {
                a = AddressesFacade.update(a);
            }
        } catch (Exception ex) {
            log.error("Failed to save people entity", ex);
        }
        response.sendRedirect("addresses.jsp?id=" + a.getPeople().getId());
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request  servlet request
     * @param response servlet response
     *
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request  servlet request
     * @param response servlet response
     *
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
