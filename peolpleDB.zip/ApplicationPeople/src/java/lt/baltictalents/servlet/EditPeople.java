package lt.baltictalents.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lt.baltictalents.bean.People;
import lt.baltictalents.facade.PeopleFacade;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@WebServlet(name = "EditPeople", urlPatterns = {"/editPeople"})
public class EditPeople extends HttpServlet {

    private static final Log log = LogFactory.getLog(EditPeople.class);

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     *
     * @param request  servlet request
     * @param response servlet response
     *
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String idParam = request.getParameter("id");
        People p = new People();
        Integer id = null;
        try {
            id = new Integer(idParam);
            p.setId(id);
        } catch (Exception ex) {
            // Ignored
        }
        p.setFirstName(request.getParameter("firstName"));
        p.setLastName(request.getParameter("lastName"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        try {
            p.setBirthDate(sdf.parse(request.getParameter("birthDate")));
        } catch (Exception ex) {
            log.warn("Failed to parse birth date. Setting today.");
            p.setBirthDate(new Date());
        }
        try {
            p.setSalary(new BigDecimal(request.getParameter("salary")));
        } catch (Exception ex) {
            log.warn("Failed to parse salary. Setting 0.");
            p.setSalary(BigDecimal.ZERO);
        }
        try {
            if (id == null) {
                PeopleFacade.add(p);
            } else {
                PeopleFacade.update(p);
            }
        } catch (Exception ex) {
            log.error("Failed to save people entity", ex);
        }
        response.sendRedirect("index.jsp");
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request  servlet request
     * @param response servlet response
     *
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request  servlet request
     * @param response servlet response
     *
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
